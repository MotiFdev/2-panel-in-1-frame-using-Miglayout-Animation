package moti.component;
import java.awt.Button;
import java.awt.Color;
import java.awt.Font;
import java.awt.GradientPaint;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JPanel;

import moti.swing.ButtonOutLine;
import net.miginfocom.swing.MigLayout;

import javax.swing.JButton;
import javax.swing.JLabel;

import java.awt.event.ActionEvent;

@SuppressWarnings("serial")
public class PanelCover extends JPanel {
	private final DecimalFormat df = new DecimalFormat("##0.###");
	private ActionListener event;
	private MigLayout layout;
	private JLabel title;
	private JLabel description;
	private JLabel description1;
	private ButtonOutLine button;
	private boolean isLogin;
	/**
	 * Create the panel.
	 */
	public PanelCover() {
		setOpaque(false);
//		setLayout(null);
		layout = new MigLayout("wrap, fill","[center]", "push[]25[]2[]15[]100[]push");
		setLayout(layout);
		init();
	}
	
	private void init() {
		title = new JLabel("Welcome Back!");
		title.setFont(new Font("sansserif", 1, 20));
		title.setForeground(new Color(245,245,245));
		add(title);
		
		description = new JLabel("To Keep connected with us please");
		description.setFont(new Font("sansserif", 0, 11));
		description.setForeground(new Color(255,255,255));
		add(description);
		
		description1 = new JLabel("login with your personal info");
		description1.setFont(new Font("sansserif", 0, 11));
		description1.setForeground(new Color(255,255,255));
		add(description1);
		
		button = new ButtonOutLine();
		button.setBackground(new Color(255,255,255));
		button.setForeground(new Color(255,255,255));
		button.setText("SIGN IN");
		button.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				event.actionPerformed(e);
				
			}
		});
		
		add(button,"w 60%, h 5%");
	}
	
	@Override
	protected void paintComponent(Graphics g) {
	    super.paintComponent(g);
	    Graphics2D g2 = (Graphics2D) g;
	    GradientPaint gra = new GradientPaint(0, 0, new Color(0x352F44), 0, getHeight(), new Color(0x5C5470));
	    g2.setPaint(gra);
	    g2.fillRect(0, 0, getWidth(), getHeight());
	}
	
	public void addEvent(ActionListener event) {
		this.event = event;
	}
	
	public void registerleft(double v) {
		v= Double.valueOf(df.format(v));
		login(false);
		layout.setComponentConstraints(title, "pad 0 -" + v + "% 0 0");
		layout.setComponentConstraints(description, "pad 0 -" + v + "% 0 0");
		layout.setComponentConstraints(description1, "pad 0 -" + v + "% 0 0");
	}
	
	public void registerRight(double v) {
		v= Double.valueOf(df.format(v));
		login(false);
		layout.setComponentConstraints(title, "pad 0 -" + v + "% 0 0");
		layout.setComponentConstraints(description, "pad 0 -" + v + "% 0 0");
		layout.setComponentConstraints(description1, "pad 0 -" + v + "% 0 0");
	}
	
	public void loginLeft(double v) {
		v= Double.valueOf(df.format(v));
		login(true);
		layout.setComponentConstraints(title, "pad 0 " + v + "% 0 " + v + "%");
		layout.setComponentConstraints(description, "pad 0 " + v + "% 0 " + v + "%");
		layout.setComponentConstraints(description1, "pad 0 " + v + "% 0 " + v + "%");
	}
	
	public void loginRight(double v) {
		v= Double.valueOf(df.format(v));
		login(true);
		layout.setComponentConstraints(title, "pad 0 " + v + "% 0 " + v + "%");
		layout.setComponentConstraints(description, "pad 0 " + v + "% 0 " + v + "%");
		layout.setComponentConstraints(description1, "pad 0 " + v + "% 0 " + v + "%");
	}
	
	public void login(boolean login) {
		if(this.isLogin != login) {
			if(login) {
				title.setText("hello, Friend!");
				description.setText("Enter your personal details");
				description1.setText("and start journey with us");
			}else {
				title.setText("Welcome Back!");
				description.setText("To Keep connected with us please");
				description1.setText("login with your personal info");
			}
		}
		this.isLogin = login;
	}
}
