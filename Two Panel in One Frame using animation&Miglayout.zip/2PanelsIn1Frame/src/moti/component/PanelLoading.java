package moti.component;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;

import javax.swing.JPanel;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import javax.swing.GroupLayout;
import javax.swing.ImageIcon;

public class PanelLoading extends JPanel {
	
	private JLabel lblNewLabel;
	
	/**
	 * Create the panel.
	 */
	public PanelLoading() {
		setOpaque(false);
		setFocusCycleRoot(true);
		setFocusable(true);
		lblNewLabel = new JLabel();
		lblNewLabel.setIcon(new ImageIcon(PanelLoading.class.getResource("/moti/icon/loading2.gif")));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel.setBounds(0, 0, 450, 300);
		add(lblNewLabel);
		setVisible(false);
		GroupLayout();
		
	}
	
	public void GroupLayout() {
		
		GroupLayout layout = new GroupLayout(this);
		this.setLayout(layout);
		layout.setHorizontalGroup(
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
						
				);
		
		layout.setVerticalGroup(
				
				layout.createParallelGroup(GroupLayout.Alignment.LEADING).addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 700, Short.MAX_VALUE)
				
				);
	        addMouseListener(new MouseAdapter() {
	        	
			});
	}
	
	@Override
	protected void paintComponent(Graphics grphcs) {
		
		 Graphics2D g2 = (Graphics2D) grphcs;
	        g2.setColor(new Color(255, 255, 255));
	        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
	        g2.fillRect(0, 0, getWidth(), getHeight());
	        g2.setComposite(AlphaComposite.SrcOver);
	        super.paintComponent(grphcs);
	}

}
