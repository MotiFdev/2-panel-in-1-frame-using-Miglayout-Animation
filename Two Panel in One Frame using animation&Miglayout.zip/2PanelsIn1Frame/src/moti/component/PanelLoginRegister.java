package moti.component;

import javax.swing.JLayeredPane;

import java.awt.Button;
import java.awt.CardLayout;
import java.awt.Color;
import java.awt.Cursor;
import java.awt.Font;
import java.awt.Image;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JPanel;

import net.miginfocom.swing.MigLayout;

import javax.swing.ImageIcon;
import javax.swing.JButton;
import javax.swing.JLabel;
import javax.swing.JTextField;

import moti.model.modeluser;
import moti.swing.MyButton;
import moti.swing.MyPasswordField;
import moti.swing.MyTextField;

@SuppressWarnings("serial")
public class PanelLoginRegister extends JLayeredPane {
	
	
	private modeluser user;
	
	public modeluser getUser() {
		return user;
	}
	
	private JPanel register;
	private JPanel login;
	private JTextField textField;
	/**
	 * Create the panel.
	 */
	public PanelLoginRegister(ActionListener eventRegister) {
		setLayout(new CardLayout(0, 0));
		register(eventRegister);
		login();
	}
	
	private void register(ActionListener eventRegister) {
		register = new JPanel();
		register.setBackground(new Color(250, 240, 230));
		add(register, "name_7984175446700");
		register.setLayout(new MigLayout("wrap", "push[center]90", "push[]15[]10[]10[]10[]20[]push[]push"));
		
		JLabel lblCreateAccount = new JLabel("Create account");
		lblCreateAccount.setFont(new Font("sansserif", 1, 30));
		lblCreateAccount.setForeground(new Color(53, 47, 68));
		register.add(lblCreateAccount, "cell 0 0");
		
		MyTextField txtuser = new MyTextField();
		txtuser.setPrefixIcon(new ImageIcon(getClass().getResource("/moti/icon/user.png")));
		txtuser.setHint("Name");
		register.add(txtuser, "w  60%");
		MyTextField txtemail = new MyTextField();
		txtemail.setPrefixIcon(new ImageIcon(getClass().getResource("/moti/icon/email.png")));
		txtemail.setHint("Email");
		register.add(txtemail, "w  60%");
		MyPasswordField txtpass = new MyPasswordField();
		txtpass.setPrefixIcon(new ImageIcon(getClass().getResource("/moti/icon/pass.png")));
		txtpass.setHint("Password");
		register.add(txtpass, "w  60%");
		MyTextField txtphone = new MyTextField();
		txtphone.setPrefixIcon(new ImageIcon(getClass().getResource("/moti/icon/phone.png")));
		txtphone.setHint("Phone number");
		register.add(txtphone, "w  60%");
		MyButton cmd = new MyButton();
		cmd.setBackground(new Color(53, 47, 68));
		cmd.setForeground(new Color(250,250,250));
		cmd.addActionListener(eventRegister);
		cmd.setText("SIGN UP");
		register.add(cmd,"w 40%, h 40");
		cmd.addActionListener(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				String userName = txtuser.getText().trim();
				String email = txtemail.getText().trim();
				String pasword = String.valueOf(txtpass.getPassword());
				user = new modeluser(0, userName, email, pasword);
				
			}
		});
		
	}
	
	private void login() {
		login = new JPanel();
		add(login, "name_7989745523900");
		login.setBackground(new Color(250, 240, 230));
		login.setLayout(new MigLayout("wrap", "push[center]125", "push[]15[]10[]0[]10[]push[]push"));
		
		JLabel lbllogin = new JLabel("Sign in");
		lbllogin.setFont(new Font("sansserif", 1, 30));
		lbllogin.setForeground(new Color(53, 47, 68));
		login.add(lbllogin, "cell 0 0");
		
		MyTextField txtuser = new MyTextField();
		txtuser.setPrefixIcon(new ImageIcon(getClass().getResource("/moti/icon/user.png")));
		txtuser.setHint("Name");
		login.add(txtuser, "w  60%");
		
		MyPasswordField txtpass = new MyPasswordField();
		txtpass.setPrefixIcon(new ImageIcon(getClass().getResource("/moti/icon/pass.png")));
		txtpass.setHint("Password");
		login.add(txtpass, "w  60%");
		
		JButton cmdforget = new JButton("Forgot your password ?");
		cmdforget.setForeground(new Color(100,100,100));
		cmdforget.setFont(new Font("sansserif",1,12));
		cmdforget.setContentAreaFilled(false);
		cmdforget.setBorderPainted(false);
		cmdforget.setCursor(new Cursor(Cursor.HAND_CURSOR));
		login.add(cmdforget);
		
		MyButton cmd = new MyButton();
		cmd.setBackground(new Color(53, 47, 68));
		cmd.setForeground(new Color(250,250,250));
		cmd.setText("SIGN IN");
		login.add(cmd,"w 40%, h 40");
	}
	
	public void showRegister(boolean show) {
		if(show) {
			register.setVisible(true);
			login.setVisible(false);
		}else {
			register.setVisible(false);
			login.setVisible(true);
		}
	}
}
