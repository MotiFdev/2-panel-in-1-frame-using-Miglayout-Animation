package moti.component;

import java.awt.AlphaComposite;
import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseAdapter;
import javax.swing.JPanel;
import javax.swing.GroupLayout;
import javax.swing.GroupLayout.Alignment;
import moti.swing.*;
import javax.swing.JLabel;
import javax.swing.SwingConstants;
import java.awt.Font;
import javax.swing.LayoutStyle.ComponentPlacement;
import javax.swing.JTextField;
import javax.swing.JButton;
import java.awt.SystemColor;
import java.awt.event.ActionListener;
import java.awt.event.ActionEvent;
public class PanelVerifyCode extends JPanel {
	private MyTextField txtverify;
	private ButtonOutLine btntlnOk;
	private ButtonOutLine btntlnCancel;

	/**
	 * Create the panel.
	
	 */
	
	public void setVisible(boolean bln){
		super.setVisible(bln);
		
		if(bln) {
			txtverify.grabFocus();
			txtverify.setText("");
		}
	}
	
	public PanelVerifyCode() {
		setOpaque(false);
		setFocusCycleRoot(true);
		super.setVisible(false);
		PanelRound panel1 = new PanelRound();
		txtverify = new MyTextField();
		txtverify.setHint("Code");
		
		GroupLayout groupLayout = new GroupLayout(this);
		groupLayout.setHorizontalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(140)
					.addComponent(panel1, GroupLayout.PREFERRED_SIZE, 409, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(200, Short.MAX_VALUE))
		);
		groupLayout.setVerticalGroup(
			groupLayout.createParallelGroup(Alignment.LEADING)
				.addGroup(groupLayout.createSequentialGroup()
					.addGap(180)
					.addComponent(panel1, GroupLayout.PREFERRED_SIZE, 155, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(218, Short.MAX_VALUE))
		);
		
		JLabel lblNewLabel = new JLabel("Verify Code");
		lblNewLabel.setBackground(new Color(53,63,63));
		lblNewLabel.setFont(new Font("Tahoma", Font.BOLD, 22));
		lblNewLabel.setHorizontalAlignment(SwingConstants.CENTER);
		
		JLabel lblNewLabel_1 = new JLabel("Check your email to get verify code");
		lblNewLabel_1.setBackground(new Color(53,63,63));
		lblNewLabel_1.setHorizontalAlignment(SwingConstants.CENTER);
		lblNewLabel_1.setFont(new Font("Tahoma", Font.PLAIN, 11));
		
		btntlnOk = new ButtonOutLine();
		btntlnOk.setText("OK");
		btntlnOk.setBackground(new Color(70, 252, 109));
		
		
		btntlnCancel = new ButtonOutLine();
		btntlnCancel.addActionListener(new ActionListener() {
			public void actionPerformed(ActionEvent e) {
				setVisible(false);
			}
		});
		btntlnCancel.setText("Cancel");
		btntlnCancel.setBackground(new Color(255, 46, 46));
		
		GroupLayout gl_panel1 = new GroupLayout(panel1);
		gl_panel1.setHorizontalGroup(
			gl_panel1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel1.createSequentialGroup()
					.addGap(139)
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 129, Short.MAX_VALUE)
					.addGap(142))
				.addGroup(gl_panel1.createSequentialGroup()
					.addGap(109)
					.addComponent(lblNewLabel_1, GroupLayout.PREFERRED_SIZE, 189, GroupLayout.PREFERRED_SIZE)
					.addContainerGap(112, Short.MAX_VALUE))
				.addGroup(gl_panel1.createSequentialGroup()
					.addGap(80)
					.addGroup(gl_panel1.createParallelGroup(Alignment.LEADING)
						.addGroup(gl_panel1.createSequentialGroup()
							.addGap(2)
							.addComponent(btntlnOk, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE)
							.addPreferredGap(ComponentPlacement.RELATED, 23, Short.MAX_VALUE)
							.addComponent(btntlnCancel, GroupLayout.PREFERRED_SIZE, 112, GroupLayout.PREFERRED_SIZE))
						.addComponent(txtverify, Alignment.TRAILING, GroupLayout.DEFAULT_SIZE, 249, Short.MAX_VALUE))
					.addGap(81))
		);
		gl_panel1.setVerticalGroup(
			gl_panel1.createParallelGroup(Alignment.LEADING)
				.addGroup(gl_panel1.createSequentialGroup()
					.addContainerGap()
					.addComponent(lblNewLabel, GroupLayout.DEFAULT_SIZE, 27, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(lblNewLabel_1, GroupLayout.DEFAULT_SIZE, 14, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.RELATED)
					.addComponent(txtverify, GroupLayout.DEFAULT_SIZE, GroupLayout.DEFAULT_SIZE, Short.MAX_VALUE)
					.addPreferredGap(ComponentPlacement.UNRELATED)
					.addGroup(gl_panel1.createParallelGroup(Alignment.BASELINE)
						.addComponent(btntlnOk, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE)
						.addComponent(btntlnCancel, GroupLayout.PREFERRED_SIZE, 30, GroupLayout.PREFERRED_SIZE))
					.addContainerGap())
		);
		panel1.setLayout(gl_panel1);
		setLayout(groupLayout);
	}
	
	@Override
	protected void paintComponent(Graphics grphcs) {
		
		 Graphics2D g2 = (Graphics2D) grphcs;
	        g2.setColor(new Color(255, 255, 255));
	        g2.setComposite(AlphaComposite.getInstance(AlphaComposite.SRC_OVER, 0.5f));
	        g2.fillRect(0, 0, getWidth(), getHeight());
	        g2.setComposite(AlphaComposite.SrcOver);
	        super.paintComponent(grphcs);
	}
	
	public String getInputCode() {
		return txtverify.getText().trim();
	}
	
	public void addEventButtonOK(ActionListener even) {
		btntlnOk.addActionListener(even);
	}
}
