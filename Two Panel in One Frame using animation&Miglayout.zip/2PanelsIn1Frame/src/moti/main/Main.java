package moti.main;
import moti.component.*;
import moti.model.modeluser;
import net.miginfocom.swing.MigLayout;
import java.awt.EventQueue;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.text.DecimalFormat;

import javax.swing.JFrame;
import javax.swing.JLayeredPane;
import javax.swing.JPanel;
import javax.swing.border.EmptyBorder;

import org.jdesktop.animation.timing.Animator;
import org.jdesktop.animation.timing.TimingTarget;
import org.jdesktop.animation.timing.TimingTargetAdapter;

public class Main extends JFrame {

	private JLayeredPane contentPane;
	/**
	 * Launch the application.
	 */
	private PanelCover cover;
	private PanelLoginRegister loginRegister;
	private PanelLoading loading;
	private PanelVerifyCode VerifyCode;
	private MigLayout layout;
	private JLayeredPane bg;
	private boolean isLogin;
	private final double addsize = 30;
	private final double coversize = 35;
	private final double LoginSize = 75;
	private final DecimalFormat df = new DecimalFormat("##0.###");
	
	public static void main(String[] args) {
		EventQueue.invokeLater(new Runnable() {
			public void run() {
				try {
					Main frame = new Main();
					frame.setVisible(true);
				} catch (Exception e) {
					e.printStackTrace();
				}
			}
		});
	}
	
	private void init() {
		
		layout = new MigLayout("fill, insets -10", "[][]", "[]");
		cover = new PanelCover();
		VerifyCode = new PanelVerifyCode();
		
		ActionListener eventRegister = new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				register();
				
			}
		};
		
		loginRegister = new PanelLoginRegister(eventRegister);
		loading = new PanelLoading();
		
		TimingTarget target = new TimingTargetAdapter() {
			@Override
			public void timingEvent(float fraction) {
				 	
				double size = coversize;
				double fractionCover;
				double fractionLogin;
				
				if(fraction <= 0.5f) {
					size += fraction * addsize;
				}else {
					size += addsize - fraction * addsize;
				}
				
				if(isLogin) {
					fractionCover = 1f - fraction;
					fractionLogin=fraction;
					
					if(fraction >= 0.5f) {
						cover.registerRight(fractionCover * 100);
					}else {
						cover.loginRight(fractionLogin * 100);
					}
					
				}else {
					fractionCover = fraction;
					fractionLogin = 1f - fraction;
					
					if(fraction <= 0.5f) {
						cover.registerleft(fraction * 100);
					}else {
						cover.loginLeft((1f - fraction) * 100);
					}
				}
				
				if(fraction >= 0.5f) {
					loginRegister.showRegister(isLogin);
				}
				fractionCover = Double.valueOf(df.format(fractionCover));
				fractionLogin = Double.valueOf(df.format(fractionLogin));
				layout.setComponentConstraints(cover, "width " + size + "%, pos "+ fractionCover + "al -5 n 120%");
				layout.setComponentConstraints(loginRegister, "width " + LoginSize + "%, pos "+ fractionLogin + "al -5 n 120%");
				contentPane.revalidate();
			}
			@Override
			public void end() {
				isLogin =! isLogin;
			}
		};
		
		Animator animator = new Animator(1000, target);
		animator.setAcceleration(0.5f);
		animator.setDeceleration(0.5f);
		animator.setResolution(0);
		contentPane.setLayer(loading, JLayeredPane.POPUP_LAYER);
		contentPane.setLayer(VerifyCode, JLayeredPane.POPUP_LAYER);
		contentPane.add(loading, "cell 0 0");
		contentPane.add(VerifyCode, "");
		contentPane.setLayout(layout);
		contentPane.add(cover, "pos 0al -5 null 120%,cell 0 0,width 35%");
		contentPane.add(loginRegister, "pos 1al -5 null 120%,cell 0 0,width 75%");
		cover.addEvent(new ActionListener() {
			
			@Override
			public void actionPerformed(ActionEvent e) {
				// TODO Auto-generated method stub
				if(!animator.isRunning()) {
					animator.start();
				}
				
			}
		});
	}
	
	private void register() {
//		contentPane.remove(loading);
////		loading.setVisible(false);
//		VerifyCode.setVisible(true);
		modeluser user = loginRegister.getUser();
		
		System.out.println(user.getuserName());
	}

	/**
	 * Create the frame.
	 */
	public Main() {
		setUndecorated(true);
		setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		setTitle(" ");
		setResizable(true);
		setBounds(100, 100, 686, 530);
		contentPane = new JLayeredPane();
		contentPane.setBorder(new EmptyBorder(5, 5, 5, 5));
		setLocationRelativeTo(null);
		setContentPane(contentPane);
		init();
	}

}
