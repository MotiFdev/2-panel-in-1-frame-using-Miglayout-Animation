package moti.model;

public class modeluser {
	
	int userID;
	String userName;
	String email;
	String verifyCode;
	
	public void setuserID(int userID) {
		this.userID = userID;
	}
	
	public int getuserID() {
		return userID;
	}
	
	public String getuserName() {
		return userName;
	}
	public void setuserName(String userName) {
		this.userName = userName;
	}

	
	public String getemail() {
		return email;
	}
	public void setemail(String email) {
		this.email = email;
	}
	
	public String getverifyCode() {
		return verifyCode;
	}
	public void setverifyCode(String verifyCode) {
		
		this.verifyCode = verifyCode;
	}
	
	public modeluser(int userID,String userName,String email,String verifyCode){
		this.userID= userID;
		this.userName = userName;
		this.email = email;
		this.verifyCode = verifyCode;
	}
	
	public modeluser(int userID,String userName,String email){
		this.userID= userID;
		this.userName = userName;
		this.email = email;
	}
	
	
}
